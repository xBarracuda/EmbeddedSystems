/**
 * Vorlage Praktikum 4: main.c
 **/

#if !defined(__SOFT_FP__) && defined(__ARM_FP)
  #warning "FPU is not initialized, but the project is compiling for an FPU. Please initialize the FPU before use."
#endif

#include <stddef.h>
#include <stdint.h>

#include <STM.h>
#include <GPIO_Driver.h>
#include <LCD_Driver.h>

void delay(uint32_t a) {
	for (volatile uint32_t i = 0; i < a; i++);
}

int main(void)
{
	// LCD Handle
	LCD_Handle_t lcd_config;

	// Einrichten der Felder des LCD Handles
	for (int i = 0; i<8; i++){
		memset(&(lcd_config.pGPIO_Data[i]), 0, sizeof(lcd_config.pGPIO_Data[i]));
		lcd_config.pGPIO_Data[i].pGPIOx = GPIOD;
		lcd_config.pGPIO_Data[i].GPIO_PinConfig.GPIO_PinNumber = i;
	}
	memset(&(lcd_config.RS), 0, sizeof(lcd_config.RS));
	lcd_config.RS.pGPIOx = GPIOD;
	lcd_config.RS.GPIO_PinConfig.GPIO_PinNumber = 12;

	memset(&(lcd_config.Enable), 0, sizeof(lcd_config.Enable));
	lcd_config.Enable.pGPIOx = GPIOD;
	lcd_config.Enable.GPIO_PinConfig.GPIO_PinNumber = 14;

	// InitialisiereDisplay
	lcd_init(&lcd_config);
	delay(2000);
	// Setze Display zurück
	lcd_command(&lcd_config, CMD_LCD_CLEAR);
	delay(2000);
	// Setze Modus 2 Linien mit 8 Bit-Übertragung
	lcd_command(&lcd_config, CMD_LCD_SET_8BIT_2LINE);
	delay(2000);
	// Schaltet das ganze Display und blinkenden Cursor an
	lcd_command(&lcd_config, CMD_LCD_CONTROL_ON);
	delay(2000);
	// Print Text
	char* text = "Willkommen in Embedded Software!\0";
	uint32_t delayValue = 10000;
	printText(&lcd_config, text, delayValue);
	uint16_t counter = 0;
	// Ausgabe langsam Buchstabe für Buchstabe

	delayValue = 100000;
	delay(5000000);
	while (1){
		printText(&lcd_config, text, delayValue);
		delay(delayValue);
	}
}

