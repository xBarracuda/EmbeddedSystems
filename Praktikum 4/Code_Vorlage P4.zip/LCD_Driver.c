/**
 * Vorlage Praktikum 4: LCD_Driver.c
 **/

#include "LCD_Driver.h"


void delay_LCD(uint32_t a) {
	for (volatile uint32_t i = 0; i < a; i++);
}

//Todo: Implementieren Sie die leeren Funktionen!
// Nutzen Die dazu Ihren GPIO-Treiber

void setRS(LCD_Handle_t* lcd_config){

}

void resetRS(LCD_Handle_t* lcd_config){

}


void setEnable(LCD_Handle_t* lcd_config){

}

void resetEnable(LCD_Handle_t* lcd_config){

}

void toggleEnable(LCD_Handle_t* lcd_config)
{

}

// Sendet das Kommando in cmd angegebene Kommando an das Display (instruction Mode)
// und führt es aus.
void lcd_command(LCD_Handle_t* lcd_config, uint8_t cmd)
{

}

// Setzt die 8 Datenbits auf die in Value angegebenen Werte
void setDataBits(uint8_t value, LCD_Handle_t* lcd_config){

}

// Inistialiserung des Displays
void lcd_init(LCD_Handle_t* lcd_config){

}


void printLetter(LCD_Handle_t* lcd_config, uint8_t letter)
{

}

// Diese Funktion brauchen Sie nicht zu modifizieren. Die dient dem Test in der main.c
void printText(LCD_Handle_t* lcd_config, char *Text, uint32_t delayvalue)
{
	lcd_command(lcd_config, CMD_LCD_CLEAR);
	delay_LCD(delayvalue);
	// Print a text to the display
	char *tmp = Text;
	uint8_t counter = 0;

	while(*tmp != '\0')
	{
		printLetter(lcd_config, *tmp);
		tmp++;
		counter++;
		delay_LCD(delayvalue);
		if(counter > 16)
		{
			lcd_command(lcd_config, CMD_LCD_SET_SECOND_LINE);
			delay_LCD(delayvalue);
			counter = 0;
		}
	}
}
